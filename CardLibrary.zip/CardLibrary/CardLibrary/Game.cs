﻿using System.Text;

namespace CardLibrary
{
    public class Game
    {
        public List<Card> Deck { get; protected set; }
        public List<Card> Dealt { get; protected set; }
        public List<Card> Discard { get; protected set; }


        // Start a new game with default settings
        public Game() => Init(GameSettings.GetDefaultCards());
        public Game(GameSettings gameSetting) => Init(gameSetting.cards);

        protected virtual void Init(List<Card> cards)
        {
            Deck = cards;
            Dealt = new();
            Discard = new();

            ShuffleDeck();
        }

        public bool DeckHasCards { get => Deck.Count > 0; }

        public virtual void ShuffleDeck() => Deck = Deck.Shuffle();

        public virtual void ShuffleAll()
        {
            var newDeck = Deck.Concat(Dealt).Concat(Discard).ToList();
            newDeck.Shuffle();
            Deck = newDeck;
            Discard.Clear();
            Dealt.Clear();
        }

        public void SortDeck() => Deck = Deck.OrderByDescending(x => x.suit).ThenBy(x => x.value).ToList();

        public virtual List<Card> Deal(int amount)
        {
            int available = amount > Deck.Count ? Deck.Count : amount;
            if (available <= 0) return null;

            var nItems = Deck.Take(available);
            Deck.RemoveRange(0, available);      
            Dealt.AddRange(nItems);

            return nItems.ToList();
        }

        public void DiscardCards(List<Card> cards)
        {
            foreach (var card in cards)
            {
                if (!Dealt.Contains(card))
                    throw new Exception("Card not dealt!");

                Dealt.Remove(card);
                Discard.Add(card);
            }
        }

        public override string ToString()
        {
            StringBuilder s = new();
            var a = Deck.Select(x => x.name).ToArray();

            if(Deck.Count > 0)
            {
                s.AppendLine("Deck: ");
                s.AppendLine(string.Join(",", Deck.Select(x => x.name)));
            }
            if (Dealt.Count > 0)
            {
                s.AppendLine("Dealt: ");
                s.AppendLine(string.Join(",", Dealt.Select(x => x.name)));
            }
            if (Discard.Count > 0)
            {
                s.AppendLine("Discard: ");
                s.AppendLine(string.Join(",", Discard.Select(x => x.name)));
            }

            return s.ToString();
        }

    }

    /// <summary>
    /// Override the games settings by assigning custom cards and suits.
    /// Use GetDefaultCards to generate a default set
    /// </summary>
    public struct GameSettings
    {
        public List<Card> cards;

        public static List<Card> GetDefaultCards()
        {
            List<Card> draft = new();

            for (int i = 0; i < 52; i++)
            {
                Suit suite = (Suit)(Math.Floor((decimal)i / 13));
                //Add 2 to value as a cards start a 2
                int val = i % 13 + 2;
                draft.Add(new Card(val, suite));
            }

            return draft;
        }
    }

    public static class GameExt
    {    
        public static List<T> Shuffle<T>(this List<T> list)
        {
            Random rng = new();
            return list.OrderBy(a => rng.Next()).ToList();
        }
    }
}