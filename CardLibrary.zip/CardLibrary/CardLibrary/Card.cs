﻿using System.Text;

namespace CardLibrary
{
    public enum Suit { HEARTS, DIAMONDS, SPADES, CLUBS }

    public struct Card : IEquatable<Card>
    {
        // Using the name as ID makes it easier to check equal and hashcode 
        public string name;
        public Suit suit;
        public int value;

        public Card(int val, Suit suit) : this()
        {
            this.value = val;
            this.suit = suit;

            StringBuilder newName = new();

            switch (val)
            {
                case 11:
                    newName.Append('J');
                    break;
                case 12:
                    newName.Append('Q');
                    break;
                case 13:
                    newName.Append('K');
                    break;
                case 14:
                    newName.Append('A');
                    break;
                default:
                    newName.Append(val);
                    break;
            }

            newName.Append(char.ToLower(suit.ToString()[0]));
            this.name = newName.ToString();
        }

        public bool IsMoreValuable(Card other) => value > other.value;
        public bool EqualValuable(Card other) => value == other.value;
        public static Card GetMostValuableCard(List<Card> cards) => cards.MaxBy(card => card.value);

        public bool Equals(Card other) => name == other.name;

        public override bool Equals(object obj) => obj is Card card && Equals(card);
        public override int GetHashCode() => name.GetHashCode();

        public static bool operator ==(Card left, Card right) => left.Equals(right);
        public static bool operator !=(Card left, Card right) => !(left == right);
    }

}
