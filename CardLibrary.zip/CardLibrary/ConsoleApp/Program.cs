﻿using CardLibrary;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Generate quick tests to meet assessment.

            var gameSetting = new GameSettings()
            {
                cards = GameSettings.GetDefaultCards()
            };

            var game = new Game(gameSetting);
            Console.WriteLine("Current card count: " + game.Deck.Count);
            Console.WriteLine();

            // shuffled?
            Console.WriteLine("Check if shuffled:");
            Console.WriteLine(game.ToString());

            // sorted?
            game.SortDeck();
            Console.WriteLine("Check if sorted:");
            Console.WriteLine(game.ToString());

            // Deal 5 cards, until all drawn
            Console.WriteLine("Lets draw 5 until all drawn:");
            bool done = false;
            while (!done)
            {
                var a = game.Deal(5);

                if(a != null)
                    Console.WriteLine(string.Join(",", a.Select(x => x.name)));
                else
                    done = true;
            }
            Console.WriteLine("Check game state after draw 5:");
            Console.WriteLine(game.ToString());

            // reshuffle all
            game.ShuffleAll();
            Console.WriteLine("Re-shuffle all cards");
            Console.WriteLine(game.ToString());

            // lets draw 5 cards and check which is most valuable
            var five = game.Deal(5);
            Console.WriteLine("Most valuable of 5:");
            Console.WriteLine(Card.GetMostValuableCard(five).name + " from " + string.Join(",", five.Select(x => x.name)));

            // lets Discard the 5 cards
            game.DiscardCards(five);
            Console.WriteLine();
            Console.WriteLine("Discard the 5 cards:");
            Console.WriteLine(game.ToString());

            Console.ReadLine();
        }
    }
}